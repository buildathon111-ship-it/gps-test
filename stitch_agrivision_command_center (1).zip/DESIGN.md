---
name: AgriVision AI
colors:
  surface: '#f9faf8'
  surface-dim: '#d9dad8'
  surface-bright: '#f9faf8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f4f2'
  surface-container: '#edeeec'
  surface-container-high: '#e7e8e6'
  surface-container-highest: '#e1e3e1'
  on-surface: '#191c1b'
  on-surface-variant: '#434843'
  inverse-surface: '#2e3130'
  inverse-on-surface: '#f0f1ef'
  outline: '#737973'
  outline-variant: '#c3c8c1'
  surface-tint: '#4d6453'
  primary: '#061b0e'
  on-primary: '#ffffff'
  primary-container: '#1b3022'
  on-primary-container: '#819986'
  inverse-primary: '#b4cdb8'
  secondary: '#3b6934'
  on-secondary: '#ffffff'
  secondary-container: '#b9eeab'
  on-secondary-container: '#3f6d38'
  tertiary: '#001d02'
  on-tertiary: '#ffffff'
  tertiary-container: '#003405'
  on-tertiary-container: '#6ca063'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d0e9d4'
  primary-fixed-dim: '#b4cdb8'
  on-primary-fixed: '#0b2013'
  on-primary-fixed-variant: '#364c3c'
  secondary-fixed: '#bcf0ae'
  secondary-fixed-dim: '#a1d494'
  on-secondary-fixed: '#002201'
  on-secondary-fixed-variant: '#23501e'
  tertiary-fixed: '#b9f1ad'
  tertiary-fixed-dim: '#9ed493'
  on-tertiary-fixed: '#002202'
  on-tertiary-fixed-variant: '#20511e'
  background: '#f9faf8'
  on-background: '#191c1b'
  surface-variant: '#e1e3e1'
typography:
  display-lg:
    fontFamily: Manrope
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Manrope
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Manrope
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: Manrope
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  title-md:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-caps:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.05em
  mono-data:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: -0.01em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 24px
  lg: 40px
  xl: 64px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 48px
---

## Brand & Style

The design system is engineered for the high-stakes world of precision agriculture, balancing rugged reliability with advanced computational intelligence. The brand personality is authoritative, observant, and sustainable—evoking the feeling of a sophisticated laboratory placed directly into the field.

The visual style blends **Corporate Modern** efficiency with **Tactile** data visualization. It prioritizes clarity and high-density information architecture while maintaining a premium feel through generous whitespace and refined geometric surfaces. The aesthetic objective is to transform complex telemetry into actionable, calm insights, reducing cognitive load for operators managing large-scale biological and mechanical assets.

## Colors

The palette is rooted in the "Deep Forest" and "Rich Agricultural" greens, providing a grounded, professional foundation. The background utilizes a warm off-white to reduce glare during outdoor use while maintaining a clean, technical appearance.

- **Primary & Secondary:** Used for top-level navigation, structural headers, and primary actions.
- **Accents:** "Warm Sand" and "Earth Brown" are used for environmental data points (soil, irrigation), while "Leaf Green" and "Soft Lime" denote growth metrics and biological health.
- **Status:** High-saturation tones reserved strictly for telemetry alerts, weather changes, and system health.
- **Overlays:** Use semi-transparent variations of the Primary color for GIS map interfaces to ensure legibility against satellite imagery.

## Typography

This design system utilizes a dual-font strategy. **Manrope** is used for headlines and display elements to provide a modern, refined, and slightly technical character. **Inter** is used for all functional UI, body copy, and data readouts due to its exceptional legibility and systematic performance in dense layouts.

Numeric data within telemetry cards should utilize slightly tighter letter spacing to maintain a compact, "instrument panel" feel. Use the `label-caps` style for category headers and table columns to establish a clear information hierarchy.

## Layout & Spacing

The layout follows a **Fluid Grid** model built on an 8px base unit. 

- **Desktop:** 12-column grid with 24px gutters. Content is typically housed in modular containers that span 3, 4, or 6 columns.
- **Tablet:** 8-column grid with 20px gutters. 
- **Mobile:** 4-column grid with 16px margins. 

The "Data-Driven Hierarchy" is achieved by using the `lg` (40px) spacing between major functional sections and `sm` (12px) spacing between related telemetry metrics. Use standardized "Safe Areas" for GIS map overlays, ensuring floating action buttons (FABs) and legends do not obscure critical center-map data.

## Elevation & Depth

Hierarchy is established through **Tonal Layering** and **Low-Contrast Outlines**. 

- **Surface 0 (Background):** The off-white base layer.
- **Surface 1 (Cards):** Pure white backgrounds with a 1px border (#E1E4DF). This is the primary container for AI insights and data.
- **Surface 2 (Popovers/Modals):** Pure white with a "Subtle Soft Shadow" (0px 4px 20px rgba(27, 48, 34, 0.08)).
- **Depth Markers:** Use a very subtle inner shadow on input fields and telemetry wells to give a "carved" technical look. Avoid heavy dropshadows; the focus should remain on the content and flat, crisp borders.

## Shapes

The shape language is "Professional-Organic." While the core grid is rigid and technical, components use a **Rounded** (0.5rem) corner radius to evoke a more approachable and modern feel.

- **Standard Cards:** 16px (rounded-lg) to create distinct separation of AI modules.
- **Buttons & Inputs:** 8px (standard) for a crisp, functional appearance.
- **Status Badges:** Fully pill-shaped (rounded-full) to distinguish them from interactive buttons.
- **GIS Overlays:** Use 12px rounding on all floating panels to maintain consistency with the main dashboard cards.

## Components

- **AI Insight Cards:** Featured cards using the Primary Deep Green as a header or border accent. They include a small "Sparkle" or "AI" icon and use `title-md` for the summary text.
- **Telemetry Readouts:** Components that pair a large numeric value (`headline-lg`) with a small label (`label-caps`) and a sparkline or status indicator.
- **Status Badges:** Small, pill-shaped labels with a 4px dot indicator on the left. The dot should use the Status colors defined in the palette.
- **Buttons:** 
  - *Primary:* Deep Forest Green background with White text.
  - *Secondary:* Transparent with a 1px border of Rich Agricultural Green.
  - *Actionable Accents:* Soft Lime is used sparingly for "New Action" or "Start" buttons to draw immediate attention.
- **Inputs:** Clean, 1px bordered fields that turn Rich Agricultural Green on focus. Error states use the Critical Red for both the border and a small helper text.
- **GIS Map Overlays:** Translucent white panels (85% opacity) with a backdrop blur of 10px. Controls are high-contrast (Deep Forest Green icons on White circles).